<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic Dependent Dropdown</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <meta name="_token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
    <div class="bg p-3 text-white shadow-lg text-center">
    <h4 class="bg text-center text-light">Dynamic Dependent Dropdown</h4>
    </div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10 mt-3">
                <div class="cardcard-primary p-4 border-0 shadow-lg">
                    <form action="" name="frm" id="frm" method="post">
                        <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <h4 class="text-center text-decoration-underline">Users</h4>
                        
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Country</th>
                                    <th>State</th>
                                    <th>City</th>
                                    <th class="text-center">Action</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class=""><?php echo e($users->id); ?></td>
                                    <td><?php echo e($users->name); ?></td>
                                    <td><?php echo e($users->email); ?></td>
                                    <td><?php echo e($users->country); ?></td>
                                    <td><?php echo e($users->state); ?></td>
                                    <td><?php echo e($users->city); ?></td>
                                    <td class="text-center">
                                        <a href="<?php echo e(url('edit/'.$users->id)); ?>">
                                        <button type="button" name="" id="" class="btn btn-warning" btn-lg btn-block">Edit</button>
                                        </a>

                                    </td>



                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                               
                            </tbody>
                        </table>

                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\project1\resources\views/users/list.blade.php ENDPATH**/ ?>