<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic Dependent Dropdown</title>
    <link rel="stylesheet" href="{{asset('assets/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/style.css')}}">
    <meta name="_token" content="{{ csrf_token() }}">
</head>
<body>
    <div class="bg p-3 text-white shadow-lg text-center">
    <h4 class="bg text-center text-light">Dynamic Dependent Dropdown</h4>
    </div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 mt-3">
                <div class="cardcard-primary p-4 border-0 shadow-lg">
                    <form action="" name="frm" id="frm" method="post">
                        @csrf
                    <div class="card-body">
                        <h4 class="text-center text-decoration-underline">Contact Form By Country, State and City</h4>
                        <div class="mb-3">
                            <input type="text" class="form-control-lg form-control" name="name" id="name" placeholder="Enter Name">
                            <p class="invalid-feedback" id="name-error">This name field is Required</p>
                        </div>
                        <div class="mb-3">
                            <input type="email" class="form-control-lg form-control" name="email" id="email" placeholder="Enter Email">
                            <p class="invalid-feedback" id="email-error">This email field is Required</p>
                        </div>
                        <div class="mb-3">
                        <select name="country" id="country" class="form-control-lg form-control">
                            <option value="">Select Country</option>
                            @if(!empty($countries))
                            @foreach($countries as $country)
                                <option value="{{$country->id}}">{{$country->name}}</option>
                            @endforeach
                            @endif
                        </select>
                        </div>

                        <div class="mb-3">
                        <select name="state" id="state" class="form-control-lg form-control">
                            <option value="">Select State</option>
                        </select>
                        </div>

                        <div class="mb-3">
                        <select name="city" id="city" class="form-control-lg form-control">
                            <option value="">Select City</option>
                        </select>
                        </div>


                        <div class="mb-3">
                        <label class="form-label" for="customFile">Drop your file here</label>
                        <input type="file" class="form-control" id="customFile" />
                        </div>

                        <div class="mb-3">  
                            <button class="btn btn-primary btn-lg">Create</button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<script src="{{asset('assets/js/jquery-3.6.0.min.js')}}"></script>
<script src="{{asset('assets/js/bootstrap.min.js')}}"></script>

<script>
    $.ajaxSetup({
         headers: {
            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
         }
   });

   $(document).ready(function(){
    $('#country').change(function(){
        var country_id = $(this).val();

        if(country_id == ""){
            var country_id = 0;
        }
            $.ajax({
                url: '{{url("/fetch-states/")}}/'+country_id,
                type: 'post',
                datatype: 'json',
                success: function(response){
                    $('#state').find('option:not(:first)').remove();
                    $('#city').find('option:not(:first)').remove();
                    if(response['states'].length > 0){
                        $.each(response['states'], function(key, value){
                            $("#state").append("<option value='"+value['id']+"'>"+value['name']+"</Option>")
                        });
                    }
                }

            });
       
    });



    $('#state').change(function(){
        var state_id = $(this).val();

        if(state_id == ""){
            var state_id = 0;
        }
                $.ajax({
                    url: '{{url("/fetch-cities/")}}/'+state_id,
                    type: 'post',
                    datatype: 'json',
                    success: function(response){
                        $('#city').find('option:not(:first)').remove();

                        if(response['cities'].length > 0){
                            $.each(response['cities'], function(key, value){
                                $("#city").append("<option value='"+value['id']+"'>"+value['name']+"</Option>")
                            });
                        }
                    }

                });
       
    });

   });


   $("#frm").submit(function(event){
        event.preventDefault();
        $.ajax({
           url: '{{url("/save")}}/',
           type: 'post',
           data: $("#frm").serializeArray(),
           datatype: 'json',
           success: function(response){

            if(response['status'] == 1){

            }else{

                if (response['errors']['name']) {
                    $("#name").addClass('is-invalid');
                   $('name-error').html(response['errors']['name']);
                }else{
                    $("#name").removeClass('is-invalid');
                   $('name-error').html("");
                }


                if (response['errors']['email']) {
                    $("#email").addClass('is-invalid');
                   $('email-error').html(response['errors']['email']);
                }else{
                    $("#email").removeClass('is-invalid');
                   $('email-error').html("");
                }
            }

           }     

        });

   });
</script>